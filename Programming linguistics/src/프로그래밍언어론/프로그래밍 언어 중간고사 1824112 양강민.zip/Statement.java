package 프로그래밍언어론;

class Statement {

	public void display(int levels) { }

}
